---
    layout: default
    title: Coding
    tagline: Resources
---

## Resources for Coding

#### General

https://www.edx.org/
https://news.ycombinator.com/item?id=1893151

#### Javascript

http://javascriptissexy.com/how-to-learn-javascript-properly/
